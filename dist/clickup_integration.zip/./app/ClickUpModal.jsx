

function ClickUpModal() {
  return (
    <div>
      Click Up Ticket Details
    </div>
  )
}

ReactDOM.render(
  <ClickUpModal />,
  document.getElementById('root')
) 
