# clickup_integration
freshdesk to click-up ticket integration

git clone

npm install

fdk run

go to freshdesk ticket and add "?dev=true" to end of url
